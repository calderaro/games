var Spritesheet = function(filename)
{
    this.image = new Image();
    this.image.src = filename;
};